public class Message {
	private int id;
	private static int id_gen = 0;

	private int from;
	private int to;
	private String message;

	public Message(int from, int to, String message){
		generateId();
		setFrom(from);
		setTo(to);
		setMessage(message);
	}

	private void generateId(){
		id = id_gen++;
	}

	public int getFrom(){
		return from;
	}

	public void setFrom(int from){
		this.from = from;
	}

	public int getTo(){
		return to;
	}

	public void setTo(int to){
		this.to = to;
	}

	public String getMessage(){
		return message;
	}

	public void setMessage(String message){
		this.message = message;
	}
}
